export default {
	content: [
		"./index.html",
		"./src/**/*.{js,ts,jsx,tsx}",
	],
	theme: {
		extend: {
			backgroundImage: {
				'day': "url('./assets/day-background.webp')",
				'night': "url('./assets/night-background.webp')",
			},
			fontFamily: {
				'roboto': ['roboto', 'sans-serif']
			},
		},
	},
	plugins: [],
}