import fewClouds from '../assets/02d.svg';

const Weather = (props) => {
    const { city, data, children } = props;
    const Title = city ? null : <div className='flex flex-col items-center justify-center mt-5 text-white font-roboto h-60'><img className='w-48 h-48' src={ fewClouds } alt="Weather" /><h1 className="text-3xl font-medium sm:text-4xl md:text-5xl">Weather Forecast</h1></div>;

    return (
        <div className={ `relative w-full max-w-md px-4 py-8 bg-white border border-transparent shadow-lg bg-opacity-10 rounded-3xl md:px-6 md:max-w-lg ${ city ? 'h-[578px]' : 'h-[481px]' }` }>
            <div className={ `flex flex-col items-center h-full ${ city ? 'gap-24' : 'gap-10' }` }>
                <div className='flex flex-col items-center justify-center w-full h-auto lg:flex-row'>
                    { Title }
                    <div className={ `text-center text-white font-roboto ${ city ? 'block opacity-100 mt-3' : 'hidden opacity-0 mt-0' }` } >
                        <h3 className='text-2xl font-medium'>{ city }</h3>
                        <p className='relative text-8xl mb-1.5'>{ data ? Math.round(data.temp - 273.15) : 0 }<span className='absolute top-1.5 text-3xl ml-1 font-medium'>°C</span></p>
                        <p className='text-lg md:text-xl'>{ data ? data.weather_desc.charAt(0).toUpperCase() + data.weather_desc.slice(1) : '' }</p>
                    </div>
                </div>
                { children }
            </div>
        </div>
    )
};

export default Weather;
