import clearSky from '../assets/01d.svg';
import iconMapping from './iconMapping';

// RETURNS THE DAY OF THE WEEK FOR A GIVEN DATA
const getDay = (date) => {
    const weekday = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return weekday[new Date(date).getDay()];
};

// CHECK IF A GIVEN DATE IS YESTERDAY
const isYesterday = (someDate) => {
    const today = new Date
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    return someDate.getDate() === yesterday.getDate() && someDate.getMonth() === yesterday.getMonth() && someDate.getFullYear() === yesterday.getFullYear();
}

// CHECK IF A GIVEN DATE IS TODAY
const isToday = (someDate) => {
    const today = new Date();
    return someDate.getDate() === today.getDate() && someDate.getMonth() === today.getMonth() && someDate.getFullYear() === today.getFullYear();
};

// CHECK IF A GIVEN DATE IS TOMORROW
const isTomorrow = (someDate) => {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);
    return someDate.getDate() === tomorrow.getDate() && someDate.getMonth() === tomorrow.getMonth() && someDate.getFullYear() === tomorrow.getFullYear();
};

// FORMATS A GIVEN DATE TO A STRING WITHOUT THE YEAR
const formatDateWithoutYear = (date) => {
    const options = {month: '2-digit', day: '2-digit' };
    return new Date(date).toLocaleDateString(undefined, options);
};

const WeatherDate = (props) => {
    const { date, icon, weather_desc } = props;

    const getWeatherIcon = (icon) => {
        return iconMapping[icon] || clearSky;
    };

    return (
        <div className={ `w-20 h-32 flex flex-col items-center justify-start text-white font-roboto` }>
            <h3 className='text-sm'>{ isYesterday(new Date(date)) ? 'Yesterday' : isToday(new Date(date)) ? 'Today' : isTomorrow(new Date(date)) ? 'Tomorrow' : getDay(new Date(date)) }</h3>
            <span className='text-sm'>{ formatDateWithoutYear(date) }</span>
            <img src={ getWeatherIcon(icon) } alt='Weather' className={ `w-10 h-10 mt-1 mb-0 md:w-10 md:h-10` } />
            <p className='text-sm text-center'>{ weather_desc.charAt(0).toUpperCase() + weather_desc.slice(1) }</p>
        </div>
    )
}

export default WeatherDate;