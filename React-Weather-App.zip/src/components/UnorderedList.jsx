import React from 'react'

const UnorderedList = ({ children }) => {
  return (
    <ul className='no-scrollbar w-full flex flex-row items-center justify-start gap-3 overflow-x-auto overflow-hidden sm:items-center sm:gap-4'>{ children }</ul>
  )
}

export default UnorderedList