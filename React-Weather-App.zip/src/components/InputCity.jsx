const InputCity = (props) => {
    const { makeApiCall, city } = props;
    const onClickHandler = async (event) => {
        event.persist();
        const eventKey = event.which ? event.which : event.keyCode;
        const city = event.target.value;
    
        if(eventKey == 13) {
            if(/^[a-zA-ZäöüÄÖÜß ]+$/.test(city)) {
                event.target.classList.add('loading');

                const isSuccessful = await makeApiCall(city);
                if(isSuccessful) {
                    event.target.placeholder = 'Enter a City...';
                } else {
                    event.target.placeholder = 'City was not found, please try again...';
                }
                event.target.classList.remove('loading');
            } else {
                event.target.placeholder = 'Please enter a valid city name...';
            }
            event.target.value = '';
        }
    };
    return (
        <div className={ `w-full text-center ${ city ? 'absolute -top-[10%] max-w-72 sm:max-w-none' : 'static max-w-none' }` }>
            <input className='w-full h-12 max-w-xs px-6 text-lg bg-white rounded-full shadow-md font-roboto bg-opacity-60 placeholder:text-gray-500 focus:shadow-none focus:border-2 focus:bg-opacity-100 focus:border-black placeholder:focus:text-black focus:outline-none' type='text' placeholder='Enter a City...' onKeyDown={ onClickHandler } />
        </div>
    )
};

export default InputCity;