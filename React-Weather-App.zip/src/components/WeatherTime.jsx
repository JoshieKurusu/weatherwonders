import iconMapping from './iconMapping';
import UnorderedList from './UnorderedList';

const WeatherTime = ({ hourlyData }) => {
    return (
        <UnorderedList>
            { hourlyData.map((hour, index) => {
                const iconUrl = iconMapping[hour.weather[0].icon] || iconMapping['default'];
                return (
                    <li key={ index }>
                        <div className='flex flex-col items-center justify-start w-20 h-24 text-white font-roboto'>
                            <p className='text-sm'>{ new Date(hour.dt * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }</p>
                            <img src={ iconUrl } alt={ hour.weather[0].description } className={ `w-10 h-10 mt-1 mb-0 md:w-10 md:h-10` } />
                            <p className='text-base'>{ Math.round(hour.main.temp - 273.15) } °C</p>
                        </div>
                    </li>
                );
            }) }
        </UnorderedList>
    )
}

export default WeatherTime