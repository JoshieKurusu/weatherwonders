import React, { useState, useEffect } from "react";
import Weather from "./components/Weather";
import InputCity from "./components/InputCity";
import WeatherDate from "./components/WeatherDate";
import WeatherTime from "./components/WeatherTime";
import UnorderedList from "./components/UnorderedList";


const App = () => {
    const [city, setCity] = useState(undefined);
    const [days, setDays] = useState(new Array(5));
    const [currentTime] = useState(new Date());
    const [hourlyData, setHourlyData] = useState([]);

    // FIND THE INDICES OF THE WEATHER DATA FOR 5 SPECIFIC DAYS AT 3PM
    const getDayIndices = (data) => {
        let dayIndices = [];
        dayIndices.push(0);

        let index = 0;
        let tmp = data.list[index].dt_txt.slice(8,10);

        for(let i = 0; i < 4; i++) {
            while(tmp === data.list[index].dt_txt.slice(8,10) || data.list[index].dt_txt.slice(11,13) !== '15') {
                index++;
            }
            dayIndices.push(index);
            tmp = data.list[index].dt_txt.slice(8,10);
        }
        return dayIndices;
    };

    // UPDATE THE STATE WITH THE CITY NAME AND WEAHTER DATA FOR 5 DAYS
    const updateState = (data) => {
        const city = data.city.name;
        const dayIndices = getDayIndices(data);
        const daysArray = [];
        
        for(let i = 0; i < 5; i++) {
            daysArray.push({
                date: data.list[dayIndices[i]].dt_txt,
                weather_desc: data.list[dayIndices[i]].weather[0].description,
                icon: data.list[dayIndices[i]].weather[0].icon,
                temp: data.list[dayIndices[i]].main.temp,
            });
        }
        setCity(city);
        setDays(daysArray);
    };

    // FETCH WEATHER DATA FROM OpenWeatherMap API AND UPDATE THE STATE
    const makeApiCall = async (cityName) => {
        const api_data = await fetch(
            `https://api.openweathermap.org/data/2.5/forecast?q=${cityName}&APPID=f1da9fe28e9e795a7b4247d3678f9d4d`
        ).then(resp => resp.json());
        
        // PARSE THE RESPONSE AND STORE THE FIRST 12 HOURS OF DATA
        setHourlyData(api_data.list.slice(0,12));

        if(api_data.cod === '200') {
            updateState(api_data);
            return true;
        } else return false;
    };

    // MAKE AN INITIAL API CALL WHEN THE COMPONENTS MOUNTS
    useEffect(() => {
        makeApiCall('initial city name');
    }, []);

    // DETERMINE WHETHER IT'S DAYTIME OR NIGHTTIME
    const getTimeOfDay = (date) => {
        const hours = date.getHours();
        if(hours >= 6 && hours < 18) {
            return 'bg-day';
        } else {
            return 'bg-night';
        }
    };

    // RENDER WEATHER DATA FOR 5 DAYS AS A LIST
    const WeatherDateBoxes = () => {
        const weatherDateBox = days.slice(0).map((day, index) => (
            <li key={ index }><WeatherDate { ...day } /></li>
        ));
        return <UnorderedList>{ weatherDateBox }</UnorderedList>
    };

    return (
        <div className={ `flex items-center justify-center w-full h-screen px-4 bg-gray-500 bg-no-repeat bg-cover bg-bottom  ${ getTimeOfDay(currentTime) }` }>
            <Weather data={ days[0] } city={ city }>
                <InputCity city={ city } makeApiCall={ makeApiCall } />
                <div className="overflow-hidden w-full max-w-[462px]">
                    <WeatherTime hourlyData={ hourlyData }/>
                    <hr className={ `${ city ? 'my-2 border-black border-opacity-40 block' : 'hidden' }` } />
                    <WeatherDateBoxes />
                </div>
            </Weather>
        </div>
    )
};

export default App;